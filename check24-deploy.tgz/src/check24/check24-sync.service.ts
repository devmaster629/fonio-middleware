import {
  ConflictException,
  Injectable,
  Logger,
  ServiceUnavailableException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ListingStatus } from '@prisma/client';
import { mapWithConcurrency } from '../common/utils/concurrency.util';
import { HostawayClient } from '../hostaway/hostaway.client';
import { HostawaySyncService } from '../hostaway/hostaway-sync.service';
import { isListingOffline, looksLikeArchivedListingApiError } from '../hostaway/listing-offline.util';
import { PrismaService } from '../prisma/prisma.service';
import {
  buildAvailabilityRanges,
  buildStandardPricingRanges,
  eachNightYmd,
} from './check24-calendar.util';
import { Check24Client } from './check24.client';
import { Check24PropertyMapper } from './check24-property.mapper';
import { Check24Property } from './check24.types';

@Injectable()
export class Check24SyncService {
  private readonly logger = new Logger(Check24SyncService.name);
  private syncInProgress = false;

  constructor(
    private readonly prisma: PrismaService,
    private readonly config: ConfigService,
    private readonly check24: Check24Client,
    private readonly hostaway: HostawayClient,
    private readonly hostawaySync: HostawaySyncService,
    private readonly mapper: Check24PropertyMapper,
  ) {}

  isConfigured(): boolean {
    return (
      this.isEnabled() &&
      this.check24.isConfigured()
    );
  }

  isEnabled(): boolean {
    return (this.config.get<string>('CHECK24_ENABLED') ?? 'false').toLowerCase() ===
      'true';
  }

  isSyncInProgress(): boolean {
    return this.syncInProgress;
  }

  async status() {
    const [mappings, bookings, lastJob] = await Promise.all([
      this.prisma.check24PropertyMapping.count(),
      this.prisma.check24Booking.count(),
      this.prisma.syncJob.findFirst({
        where: { jobType: { startsWith: 'check24:' } },
        orderBy: { startedAt: 'desc' },
      }),
    ]);

    let ping: { ok: boolean; message?: string; error?: string } = {
      ok: false,
    };
    if (this.check24.isConfigured()) {
      try {
        const p = await this.check24.ping();
        ping = { ok: true, message: p.message ?? 'pong' };
      } catch (err) {
        ping = { ok: false, error: this.check24.describeError(err) };
      }
    }

    return {
      enabled: this.isEnabled(),
      configured: this.check24.isConfigured(),
      syncInProgress: this.syncInProgress,
      mappings,
      bookings,
      ping,
      lastJob,
      baseUrl:
        this.config.get<string>('CHECK24_API_BASE_URL') ??
        'https://supplyapistaging.ferienwohnung.check24-test.de/api/v2',
    };
  }

  async syncAll(options?: {
    content?: boolean;
    availability?: boolean;
    rates?: boolean;
    listingIds?: number[];
  }) {
    if (!this.isConfigured()) {
      throw new ServiceUnavailableException(
        'CHECK24 is disabled or CHECK24_API_TOKEN is not set',
      );
    }
    if (this.syncInProgress) {
      throw new ConflictException('CHECK24 sync already running');
    }

    this.syncInProgress = true;
    const job = await this.prisma.syncJob.create({
      data: {
        jobType: 'check24:full',
        status: 'running',
        metadata: options ?? {},
      },
    });

    const doContent = options?.content !== false;
    const doAvailability = options?.availability !== false;
    const doRates = options?.rates !== false;

    try {
      const listings = await this.prisma.listing.findMany({
        where: {
          isBookable: true,
          status: ListingStatus.LIVE,
          ...(options?.listingIds?.length
            ? { hostawayId: { in: options.listingIds } }
            : {}),
        },
        include: { check24Mapping: true },
        orderBy: { hostawayId: 'asc' },
      });

      const concurrency = Number(this.config.get('CHECK24_SYNC_CONCURRENCY') ?? 2);
      const delayMs = Number(this.config.get('CHECK24_SYNC_DELAY_MS') ?? 200);

      const maxAttempts = Math.max(
        1,
        Number(this.config.get('CHECK24_SYNC_RETRY_ATTEMPTS') ?? 3),
      );
      const retryDelayMs = Math.max(
        0,
        Number(this.config.get('CHECK24_SYNC_RETRY_DELAY_MS') ?? 2000),
      );

      type ListingRow = (typeof listings)[number];
      let pending: ListingRow[] = [...listings];
      const errors: Array<{ hostawayId: number; error: string }> = [];

      for (let attempt = 1; attempt <= maxAttempts && pending.length; attempt++) {
        const failedThisRound: ListingRow[] = [];
        const attemptErrors = new Map<number, string>();

        await mapWithConcurrency(pending, concurrency, async (listing) => {
          try {
            if (doContent) await this.syncListingContent(listing.id);
            if (doAvailability) await this.syncListingAvailability(listing.id);
            if (doRates) await this.syncListingRates(listing.id);
          } catch (err) {
            const message = this.check24.describeError(err);
            // Archived / licence rejections: clear quietly — never surface as sync errors.
            if (
              isListingOffline(listing) ||
              looksLikeArchivedListingApiError(message)
            ) {
              const propertyId = this.mapper.propertyIdForHostaway(
                listing.hostawayId,
              );
              await this.upsertMapping(listing.id, propertyId, {
                lastError: null,
                enabled: false,
              });
              this.logger.log(
                `CHECK24 skipped archived/offline listing ${listing.hostawayId}: ${message}`,
              );
              return;
            }
            attemptErrors.set(listing.hostawayId, message);
            failedThisRound.push(listing);
            const propertyId = this.mapper.propertyIdForHostaway(
              listing.hostawayId,
            );
            await this.upsertMapping(listing.id, propertyId, {
              lastError: message.slice(0, 1000),
            });
            this.logger.warn(
              `CHECK24 sync failed for listing ${listing.hostawayId} (attempt ${attempt}/${maxAttempts}): ${message}`,
            );
          }
          if (delayMs > 0) {
            await new Promise((r) => setTimeout(r, delayMs));
          }
        });

        pending = failedThisRound;
        errors.length = 0;
        for (const [hostawayId, error] of attemptErrors) {
          errors.push({ hostawayId, error });
        }

        if (pending.length && attempt < maxAttempts) {
          this.logger.log(
            `CHECK24 retrying ${pending.length} failed listing(s) after ${retryDelayMs * attempt}ms…`,
          );
          if (retryDelayMs > 0) {
            await new Promise((r) => setTimeout(r, retryDelayMs * attempt));
          }
        }
      }

      const succeeded = listings.length - pending.length;
      const metadata = {
        listings: listings.length,
        contentOk: doContent ? succeeded : 0,
        availabilityOk: doAvailability ? succeeded : 0,
        ratesOk: doRates ? succeeded : 0,
        attempts: maxAttempts,
        errors,
      };
      await this.prisma.syncJob.update({
        where: { id: job.id },
        data: {
          status: errors.length ? 'completed_with_errors' : 'completed',
          finishedAt: new Date(),
          metadata,
          error: errors.length
            ? `${errors.length} listing(s) failed after ${maxAttempts} attempt(s)`
            : null,
        },
      });
      return metadata;
    } catch (err) {
      const message = this.check24.describeError(err);
      await this.prisma.syncJob.update({
        where: { id: job.id },
        data: {
          status: 'failed',
          finishedAt: new Date(),
          error: message.slice(0, 2000),
        },
      });
      throw err;
    } finally {
      this.syncInProgress = false;
    }
  }

  /** Re-push listings that still have a lastError (used by scheduler). */
  async retryFailedListings() {
    const failed = await this.prisma.check24PropertyMapping.findMany({
      where: { lastError: { not: null } },
      include: {
        listing: {
          select: { id: true, hostawayId: true, status: true, isBookable: true },
        },
      },
    });
    if (!failed.length) {
      return { attempted: 0, succeeded: 0, errors: [] as Array<{ hostawayId: number; error: string }> };
    }

    // Archived / offline units: clear stale errors silently — never retry CHECK24.
    const offline = failed.filter((m) => isListingOffline(m.listing));
    for (const mapping of offline) {
      await this.prisma.check24PropertyMapping.update({
        where: { id: mapping.id },
        data: { lastError: null, enabled: false },
      });
      this.logger.log(
        `CHECK24 cleared lastError for archived/offline listing ${mapping.listing.hostawayId}`,
      );
    }

    const activeFailed = failed.filter((m) => !isListingOffline(m.listing));
    if (!activeFailed.length) {
      return {
        attempted: 0,
        succeeded: offline.length,
        errors: [] as Array<{ hostawayId: number; error: string }>,
      };
    }

    const listingIds = activeFailed
      .map((m) => m.listing.hostawayId)
      .filter((id): id is number => Number.isFinite(id));

    const result = await this.syncAll({
      content: true,
      availability: true,
      rates: true,
      listingIds,
    });

    return {
      attempted: listingIds.length,
      succeeded: listingIds.length - (result.errors?.length ?? 0) + offline.length,
      errors: result.errors ?? [],
    };
  }

  async syncListingContent(listingId: string) {
    const listing = await this.prisma.listing.findUniqueOrThrow({
      where: { id: listingId },
    });
    if (isListingOffline(listing)) {
      const propertyId = this.mapper.propertyIdForHostaway(listing.hostawayId);
      await this.upsertMapping(listing.id, propertyId, {
        lastError: null,
        enabled: false,
      });
      this.logger.log(
        `CHECK24 skipped content sync for archived/offline listing ${listing.hostawayId}`,
      );
      return propertyId;
    }
    const remote = await this.hostaway.getListing(listing.hostawayId);
    const property = this.mapper.mapListing(listing, remote);
    await this.check24.pushProperties([property]);
    await this.upsertMapping(listing.id, property.propertyId, {
      contentSyncedAt: new Date(),
      lastError: null,
    });
    return property.propertyId;
  }

  /**
   * After a booking is imported or cancelled, refresh the Hostaway calendar
   * and push updated availability to CHECK24 immediately.
   *
   * When cancelling, pass forceOpenFrom/forceOpenTo (arrival / departure YMD).
   * Hostaway's calendar often still reports those nights closed for a while after
   * cancel — without an optimistic reopen, CHECK24 receives a push that keeps
   * the cancelled stay blocked.
   */
  async refreshAndPushAvailability(
    listingId: string,
    hostawayListingId: number,
    options?: {
      forceOpenFrom?: string;
      forceOpenTo?: string;
      /** When true, do not schedule another delayed push (used by the follow-up itself). */
      skipFollowUp?: boolean;
    },
  ): Promise<{ pushed: boolean; reason?: string }> {
    if (!this.isConfigured()) {
      return { pushed: false, reason: 'check24_not_configured' };
    }

    const listing = await this.prisma.listing.findUnique({
      where: { id: listingId },
      select: { status: true, isBookable: true, hostawayId: true },
    });
    if (listing && isListingOffline(listing)) {
      await this.prisma.check24PropertyMapping.updateMany({
        where: { listingId },
        data: { lastError: null, enabled: false },
      });
      return { pushed: false, reason: 'listing_archived_offline' };
    }

    const daysAhead = Number(this.config.get('CALENDAR_SYNC_DAYS') ?? 365);
    const today = new Date();
    const end = new Date(today);
    end.setUTCDate(end.getUTCDate() + daysAhead);
    const format = (d: Date) => d.toISOString().slice(0, 10);

    try {
      await this.hostawaySync.syncListingCalendar(
        hostawayListingId,
        format(today),
        format(end),
      );
      if (options?.forceOpenFrom && options?.forceOpenTo) {
        const forced = await this.forceOpenCalendarRange(
          listingId,
          options.forceOpenFrom,
          options.forceOpenTo,
        );
        this.logger.log(
          `CHECK24 force-opened ${forced} calendar day(s) for listing ${hostawayListingId} (${options.forceOpenFrom}→${options.forceOpenTo})`,
        );
      }
      await this.syncListingAvailability(listingId);
      this.logger.log(
        `Pushed CHECK24 availability for listing ${hostawayListingId} after booking change`,
      );

      // Hostaway calendar lag: re-sync + force-open + push again at several delays.
      if (
        !options?.skipFollowUp &&
        options?.forceOpenFrom &&
        options?.forceOpenTo
      ) {
        this.scheduleFollowUpAvailabilityPushes(
          listingId,
          hostawayListingId,
          options.forceOpenFrom,
          options.forceOpenTo,
        );
      }

      return { pushed: true };
    } catch (err) {
      const message = this.check24.describeError(err);
      this.logger.warn(
        `CHECK24 availability push failed for listing ${hostawayListingId}: ${message}`,
      );
      return { pushed: false, reason: message };
    }
  }

  /**
   * Mark nights [dateFrom, dateTo) available in the local calendar cache.
   * Upserts missing days (updateMany alone left gaps → CHECK24 kept old closed data).
   * Skips nights covered by another active (non-cancelled) local reservation.
   */
  async forceOpenCalendarRange(
    listingId: string,
    dateFrom: string,
    dateTo: string,
  ): Promise<number> {
    const nights = eachNightYmd(dateFrom, dateTo);
    if (nights.length === 0) return 0;

    const from = new Date(`${dateFrom}T00:00:00.000Z`);
    const to = new Date(`${dateTo}T00:00:00.000Z`);
    const blocking = await this.prisma.reservation.findMany({
      where: {
        listingId,
        arrivalDate: { lt: to },
        departureDate: { gt: from },
        NOT: {
          status: {
            in: [
              'cancelled',
              'canceled',
              'declined',
              'expired',
              'inquiryDenied',
              'inquiryTimedout',
              'inquiryNotPossible',
            ],
          },
        },
      },
      select: { arrivalDate: true, departureDate: true, status: true },
    });
    // Inquiries usually do not block Hostaway calendar; treat confirmed-style only.
    const blockers = blocking.filter((r) => {
      const s = (r.status || '').toLowerCase();
      return !s.startsWith('inquiry');
    });

    const blockedNights = new Set<string>();
    for (const r of blockers) {
      for (const night of eachNightYmd(
        r.arrivalDate.toISOString().slice(0, 10),
        r.departureDate.toISOString().slice(0, 10),
      )) {
        blockedNights.add(night);
      }
    }

    let touched = 0;
    for (const night of nights) {
      if (blockedNights.has(night)) continue;
      const date = new Date(`${night}T00:00:00.000Z`);
      const existing = await this.prisma.calendarDay.findUnique({
        where: {
          listingId_date: { listingId, date },
        },
        select: { id: true, isAvailable: true },
      });
      if (!existing) {
        await this.prisma.calendarDay.create({
          data: {
            listingId,
            date,
            isAvailable: true,
            syncedAt: new Date(),
          },
        });
        touched += 1;
        continue;
      }
      if (!existing.isAvailable) {
        await this.prisma.calendarDay.update({
          where: { id: existing.id },
          data: { isAvailable: true, syncedAt: new Date() },
        });
        touched += 1;
      }
    }
    return touched;
  }

  /**
   * Re-open nights for recent CHECK24 cancellations so a later Hostaway calendar
   * sync cannot keep those stays closed on CHECK24 for the hold window.
   */
  async applyRecentCancelForceOpens(
    listingId: string,
    check24PropertyId: string,
  ): Promise<number> {
    const holdHours = Number(
      this.config.get('CHECK24_CANCEL_FORCE_OPEN_HOURS') ?? 24,
    );
    if (holdHours <= 0) return 0;

    const since = new Date(Date.now() - holdHours * 3_600_000);
    const cancels = await this.prisma.check24Booking.findMany({
      where: {
        check24PropertyId,
        status: {
          in: ['cancelled', 'canceled', 'declined', 'failed'],
        },
        OR: [{ processedAt: { gte: since } }, { updatedAt: { gte: since } }],
      },
      select: { rawPayload: true, check24BookingId: true },
      take: 100,
      orderBy: { updatedAt: 'desc' },
    });

    let total = 0;
    for (const row of cancels) {
      const raw =
        row.rawPayload && typeof row.rawPayload === 'object'
          ? (row.rawPayload as Record<string, unknown>)
          : {};
      const dateFrom =
        typeof raw.dateFrom === 'string' ? raw.dateFrom.slice(0, 10) : null;
      const dateTo =
        typeof raw.dateTo === 'string' ? raw.dateTo.slice(0, 10) : null;
      if (!dateFrom || !dateTo) continue;
      total += await this.forceOpenCalendarRange(listingId, dateFrom, dateTo);
    }
    if (total > 0) {
      this.logger.log(
        `CHECK24 durable cancel reopen: ${total} day(s) for property ${check24PropertyId}`,
      );
    }
    return total;
  }

  private scheduleFollowUpAvailabilityPushes(
    listingId: string,
    hostawayListingId: number,
    forceOpenFrom: string,
    forceOpenTo: string,
  ) {
    const raw = String(
      this.config.get('CHECK24_CANCEL_AVAILABILITY_RETRY_MS') ??
        '45000,300000,900000',
    );
    const delays = raw
      .split(/[,\s]+/)
      .map((part) => Number(part))
      .filter((n) => Number.isFinite(n) && n > 0);

    for (const delayMs of delays) {
      setTimeout(() => {
        void this.refreshAndPushAvailability(listingId, hostawayListingId, {
          forceOpenFrom,
          forceOpenTo,
          skipFollowUp: true,
        })
          .then((result) => {
            this.logger.log(
              `CHECK24 follow-up availability push (+${delayMs}ms) for listing ${hostawayListingId}: pushed=${result.pushed}${
                result.reason ? ` (${result.reason})` : ''
              }`,
            );
          })
          .catch((err) => {
            this.logger.warn(
              `CHECK24 follow-up availability push (+${delayMs}ms) failed for listing ${hostawayListingId}: ${
                err instanceof Error ? err.message : err
              }`,
            );
          });
      }, delayMs);
    }
  }

  async syncListingAvailability(listingId: string) {
    const listing = await this.prisma.listing.findUniqueOrThrow({
      where: { id: listingId },
      include: { check24Mapping: true },
    });
    const propertyId =
      listing.check24Mapping?.check24PropertyId ??
      this.mapper.propertyIdForHostaway(listing.hostawayId);

    await this.applyRecentCancelForceOpens(listing.id, propertyId);

    const days = await this.prisma.calendarDay.findMany({
      where: {
        listingId: listing.id,
        date: { gte: new Date(new Date().toISOString().slice(0, 10)) },
      },
      orderBy: { date: 'asc' },
      select: {
        date: true,
        isAvailable: true,
        minNights: true,
        price: true,
      },
    });

    const ranges = buildAvailabilityRanges(days);
    if (ranges.length === 0) {
      this.logger.warn(
        `No calendar days for listing ${listing.hostawayId}; skipping availability push`,
      );
      return;
    }

    await this.check24.pushAvailability(propertyId, ranges);
    await this.upsertMapping(listing.id, propertyId, {
      availabilitySyncedAt: new Date(),
      lastError: null,
    });
  }

  async syncListingRates(listingId: string) {
    const listing = await this.prisma.listing.findUniqueOrThrow({
      where: { id: listingId },
      include: { check24Mapping: true },
    });
    const propertyId =
      listing.check24Mapping?.check24PropertyId ??
      this.mapper.propertyIdForHostaway(listing.hostawayId);

    const days = await this.prisma.calendarDay.findMany({
      where: {
        listingId: listing.id,
        date: { gte: new Date(new Date().toISOString().slice(0, 10)) },
      },
      orderBy: { date: 'asc' },
      select: {
        date: true,
        isAvailable: true,
        minNights: true,
        price: true,
      },
    });

    const standardPricing = buildStandardPricingRanges(days);
    if (standardPricing.length === 0) {
      this.logger.warn(
        `No priced calendar days for listing ${listing.hostawayId}; skipping rates push`,
      );
      return;
    }

    await this.check24.pushRates(propertyId, [
      {
        currencyCode: 'EUR',
        vat: Number(this.config.get('CHECK24_VAT_PERCENT') ?? 0),
        standardPricing,
      },
    ]);
    await this.upsertMapping(listing.id, propertyId, {
      ratesSyncedAt: new Date(),
      lastError: null,
    });
  }

  async ensureMappingForListing(listingId: string) {
    const listing = await this.prisma.listing.findUniqueOrThrow({
      where: { id: listingId },
      include: { check24Mapping: true },
    });
    if (listing.check24Mapping) return listing.check24Mapping;
    const propertyId = this.mapper.propertyIdForHostaway(listing.hostawayId);
    return this.upsertMapping(listing.id, propertyId, {});
  }

  async listMappings() {
    return this.prisma.check24PropertyMapping.findMany({
      include: {
        listing: {
          select: {
            id: true,
            hostawayId: true,
            name: true,
            city: true,
            isBookable: true,
            status: true,
          },
        },
      },
      orderBy: { updatedAt: 'desc' },
    });
  }

  async setMappingEnabled(mappingId: string, enabled: boolean) {
    return this.prisma.check24PropertyMapping.update({
      where: { id: mappingId },
      data: { enabled },
    });
  }

  async previewProperty(hostawayId: number): Promise<Check24Property> {
    const listing = await this.prisma.listing.findUnique({
      where: { hostawayId },
    });
    if (!listing) {
      throw new ServiceUnavailableException(
        `Listing ${hostawayId} not found locally — run Hostaway sync first`,
      );
    }
    const remote = await this.hostaway.getListing(hostawayId);
    return this.mapper.mapListing(listing, remote);
  }

  async findListingIdByHostawayId(hostawayId: number): Promise<string | null> {
    const listing = await this.prisma.listing.findUnique({
      where: { hostawayId },
      select: { id: true },
    });
    return listing?.id ?? null;
  }

  private async upsertMapping(
    listingId: string,
    check24PropertyId: string,
    data: {
      contentSyncedAt?: Date | null;
      availabilitySyncedAt?: Date | null;
      ratesSyncedAt?: Date | null;
      lastError?: string | null;
      enabled?: boolean;
    },
  ) {
    return this.prisma.check24PropertyMapping.upsert({
      where: { listingId },
      create: {
        listingId,
        check24PropertyId,
        enabled: data.enabled ?? true,
        contentSyncedAt: data.contentSyncedAt ?? null,
        availabilitySyncedAt: data.availabilitySyncedAt ?? null,
        ratesSyncedAt: data.ratesSyncedAt ?? null,
        lastError: data.lastError ?? null,
      },
      update: {
        check24PropertyId,
        ...data,
      },
    });
  }
}

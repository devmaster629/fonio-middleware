-- AlterEnum
ALTER TYPE "AdminRole" ADD VALUE 'BACK_OFFICE';

-- AlterEnum
ALTER TYPE "AdminRole" ADD VALUE 'SUPER_ADMIN';
